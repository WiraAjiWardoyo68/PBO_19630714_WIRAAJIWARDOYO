package com.mywiraajiwardoyo.pbo.wiraajiwardoyo.libs;

import com.mywiraajiwardoyo.pbo.wiraajiwardoyo.model.Pengguna;
import java.util.prefs.Preferences;


public class Pref {
    public void simpan(Pengguna pengguna){
        Preferences preferences = Preferences.userNodeForPackage(Pref.class);
        preferences.putInt("id", pengguna.getId());
        preferences.put("username", pengguna.getUsername());
        preferences.put("nama_lengkap", pengguna.getNamaLengkap());
        preferences.putBoolean("is_admin", pengguna.isIsAdmin());
    }

public Pengguna ambil(){
        Preferences preferences = Preferences.userNodeForPackage(Pref.class);
        
        Pengguna pengguna = new Pengguna();
        
        pengguna.setId(preferences.getInt("id",0));
        pengguna.setUsername(preferences.get("username", ""));
        pengguna.setNamaLengkap(preferences.get("nama_lengkap", ""));
        pengguna.setIsAdmin(preferences.getBoolean("is_admin", false));
        
        return pengguna;
        
    }
    
    public void hapus(){
        Preferences preferences = Preferences.userNodeForPackage(Pref.class);
        preferences.putInt("id", 0);
        preferences.put("username", "");
        preferences.put("nama_lengkap", "");
        preferences.putBoolean("is_admin", false);
    }
}


