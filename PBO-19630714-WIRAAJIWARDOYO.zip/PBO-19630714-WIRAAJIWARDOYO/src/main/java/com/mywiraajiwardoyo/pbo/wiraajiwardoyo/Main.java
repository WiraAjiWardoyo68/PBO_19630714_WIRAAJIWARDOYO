package com.mywiraajiwardoyo.pbo.wiraajiwardoyo;

import com.mywiraajiwardoyo.pbo.wiraajiwardoyo.view.admin.BarangViewFrame;



public class Main {
   public static void mail(String[] args) {

//       Pref pref = new Pref();
//       Pengguna pengguna = pref.ambil();
//       if(pengguna.getId() == 0 ){
//            LoginFrame loginFrame = new LoginFrame();
//            loginFrame.setVisible(true);
//       }else{
//            if(pengguna.isIsAdmin()){
//                MainAdminFrame mainAdminFrame = new MainAdminFrame();
//                mainAdminFrame.setVisible(true);
//            }else{
//                MainKasirFrame mainKasirFrame = new MainKasirFrame();
//                mainKasirFrame.setVisible(true);
//            }
//        }

//       Barang barang = new Barang();
//       ArrayList<Barang>list = barang.read();
//
//       for (int i = 0; i < list.size(); i++) {
//           System.out.println(list.get(i).getNamaBarang() + " ");
//           System.out.println(list.get(i).getJenisBarang().getNamajenisbarang());
//           
//       }



//        if(pengguna.getId() == 0){
//            LoginFrame loginFrame = new LoginFrame();
//            loginFrame.setVisible(true);
//        } else {
//            if(pengguna.isIsAdmin()){
//                MainAdminFrame mainAdminFrame = new MainAdminFrame();
//                mainAdminFrame.setVisible(true);
//            } else {
//                MainKasirFrame mainKasirFrame = new MainKasirFrame();
//                mainKasirFrame.setVisible(true);
//            }
//        }

// MainPublic mainPublic = new MainPublic();
//mainPublic.setVisible(true);

       
//  jenisBarang.setNamajenisbarang("Modul 5f");
//  if(jenisBarang.create()){
//      System.out.println("Simpan Berhasil");
//    }else{
//      System.out.println("Gagal Menyimpan");
//       } 

//       jenisBarang.setId(16);
//        jenisBarang.setNamajenisbarang("Modul 5f baru");
//       if(jenisBarang.create()){
//        System.out.println("Ubah Data Berhasil");
//        }else{
//        System.out.println("Gagal Menyimpan");
//        }

//        jenisBarang.setId(8);
//        if(jenisBarang.delete()){
//        System.out.println("Hapus Data Berhasil");
//        }else{
//        System.out.println("Gagal Hapus");
//        }

//        jenisBarang.setId(15);
//        if(jenisBarang.find()){
//        System.out.println(jenisBarang.getNamajenisbarang());
//        }else{
//        System.out.println("Data Tidak Ditemukan ");
//        }

//            ArrayList<JenisBarang>list = jenisBarang.read();
//       for (int i = 0; i < list.size; i++) {
//           System.out.println(list.get(i).getNamajenisbarang());
//       }
            
//         ArrayList<JenisBarang>list = jenisBarang.search();
//         for (int i = 0; i < list.size; i++) {
//           System.out.println(list.get(i).getNamajenisbarang());
//        }

//       JenisBarangViewFrame jenisBarangViewFrame = new JenisBarangViewFrame();
//       jenisBarangViewFrame.setVisible(true);

       BarangViewFrame barangViewFrame = new BarangViewFrame();
       barangViewFrame.setVisible(true);
            
    }
}
